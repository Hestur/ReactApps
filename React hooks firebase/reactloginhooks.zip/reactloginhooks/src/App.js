import React from 'react';
import Form from './Form';

const App = () => {
  return (
    <Form />
  );
};

export default App;
